// Pin Definitions
const int gsrPin = A0; // Pin connected to GSR sensor
const int pulsePin = A1; // Pin connected to Pulse Sensor

// Pulse Sensor Variables
int pulseValue = 0;
int previousPulseValue = 0;
int threshold = 550; // Initial static threshold
int peak = 0;
int trough = 1023;
bool heartbeatDetected = false;

// BPM Variables
unsigned long previousBeatTime = 0;
unsigned long currentTime = 0;
unsigned long lastHeartbeatTime = 0;
float bpm = 0;
int beatCount = 0;
const int maxBeats = 5;
float bpmSum = 0;

void setup() {
    Serial.begin(9600); // Initialize serial communication at 9600 baud
}

void loop() {
    currentTime = millis(); // Get current time

    // Read the GSR sensor value
    int gsrValue = analogRead(gsrPin);

    // Read the Pulse sensor value
    pulseValue = analogRead(pulsePin);

    // Check for peak detection (heartbeat)
    if (pulseValue > threshold && previousPulseValue < threshold) {
        peak = pulseValue;
        heartbeatDetected = true;

        // Calculate time between current and last heartbeat
        unsigned long beatTime = currentTime - lastHeartbeatTime;
        if (beatTime > 240) { // Avoid counting noise by ensuring a minimum beat interval (240 ms = 250 BPM)
            lastHeartbeatTime = currentTime;

            // Calculate BPM from time difference between beats
            float currentBpm = 60000.0 / beatTime;

            // Maintain a running average of BPM over the last few beats
            bpmSum += currentBpm;
            beatCount++;
            if (beatCount >= maxBeats) {
                bpm = bpmSum / maxBeats; // Update BPM with the average
                bpmSum = 0; // Reset BPM sum for the next cycle
                beatCount = 0; // Reset beat count
            }
        }
    } else if (pulseValue < threshold && previousPulseValue > threshold) {
        trough = pulseValue;
    }

    // Update threshold dynamically based on recent peaks and troughs
    threshold = (peak + trough) / 2;

    // Send data to Serial (formatted as JSON-like structure for React to parse)
    Serial.print("{\"GSR\":");
    Serial.print(gsrValue);
    Serial.print(", \"Pulse\":");
    Serial.print(pulseValue);
    Serial.print(", \"Heartbeat\":");
    Serial.print(heartbeatDetected ? "true" : "false");
    Serial.print(", \"BPM\":");
    Serial.print(bpm);
    Serial.println("}"); // End the line with a newline character

    // Reset heartbeat detection
    heartbeatDetected = false;

    // Store current pulse value as previous for the next iteration
    previousPulseValue = pulseValue;

    // Add a delay to slow down the loop
    delay(100); // 100ms delay
}
